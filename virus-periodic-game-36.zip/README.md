# Virus — Tabla Periódica 36 cartas
Proyecto React (Vite) con 36 cartas de la tabla periódica (algunas repetidas aleatoriamente).
Haz clic en cartas infectadas para curarlas, gana puntos, sube de nivel y evita que se dañen.

## Ejecutar localmente
Requisitos: Node.js 18+
```bash
npm install
npm run dev
```
Abre el URL que indique Vite (normalmente http://localhost:5173).
