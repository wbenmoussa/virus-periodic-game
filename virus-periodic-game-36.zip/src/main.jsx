import React from 'react'
import { createRoot } from 'react-dom/client'
import VirusPeriodicGame from './VirusPeriodicGame'
import './styles.css'
createRoot(document.getElementById('root')).render(<VirusPeriodicGame />)
