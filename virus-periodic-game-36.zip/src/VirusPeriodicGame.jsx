
import React, { useState, useEffect, useRef } from 'react';

const baseElements = [{"z": 1, "s": "H", "name": "Hidr\u00f3geno"}, {"z": 2, "s": "He", "name": "Helio"}, {"z": 3, "s": "Li", "name": "Litio"}, {"z": 4, "s": "Be", "name": "Berilio"}, {"z": 5, "s": "B", "name": "Boro"}, {"z": 6, "s": "C", "name": "Carbono"}, {"z": 7, "s": "N", "name": "Nitr\u00f3geno"}, {"z": 8, "s": "O", "name": "Ox\u00edgeno"}, {"z": 9, "s": "F", "name": "Fl\u00faor"}, {"z": 10, "s": "Ne", "name": "Ne\u00f3n"}, {"z": 11, "s": "Na", "name": "Sodio"}, {"z": 12, "s": "Mg", "name": "Magnesio"}, {"z": 13, "s": "Al", "name": "Aluminio"}, {"z": 14, "s": "Si", "name": "Silicio"}, {"z": 15, "s": "P", "name": "F\u00f3sforo"}, {"z": 16, "s": "S", "name": "Azufre"}, {"z": 17, "s": "Cl", "name": "Cloro"}, {"z": 18, "s": "Ar", "name": "Arg\u00f3n"}, {"z": 19, "s": "K", "name": "Potasio"}, {"z": 20, "s": "Ca", "name": "Calcio"}, {"z": 21, "s": "Sc", "name": "Escandio"}, {"z": 22, "s": "Ti", "name": "Titanio"}, {"z": 23, "s": "V", "name": "Vanadio"}, {"z": 24, "s": "Cr", "name": "Cromo"}, {"z": 25, "s": "Mn", "name": "Manganeso"}, {"z": 26, "s": "Fe", "name": "Hierro"}, {"z": 27, "s": "Co", "name": "Cobalto"}, {"z": 28, "s": "Ni", "name": "Niquel"}, {"z": 29, "s": "Cu", "name": "Cobre"}, {"z": 30, "s": "Zn", "name": "Cinc"}, {"z": 31, "s": "Ga", "name": "Galio"}, {"z": 32, "s": "Ge", "name": "Germanio"}, {"z": 33, "s": "As", "name": "Ars\u00e9nico"}, {"z": 34, "s": "Se", "name": "Selenio"}, {"z": 35, "s": "Br", "name": "Bromo"}, {"z": 36, "s": "Kr", "name": "Kript\u00f3n"}];

export default function VirusPeriodicGame() {
  const spawnIntervalBase = 1400;
  const initialLives = 3;
  const levelUpEvery = 12;

  const [elements, setElements] = useState(() => {
    let repeated = [...baseElements];
    for(let i=0;i<5;i++) {
      const pick = baseElements[Math.floor(Math.random()*baseElements.length)];
      repeated.push({...pick});
    }
    return repeated.map((el, idx) => ({...el, id: idx, status:'healthy'}));
  });

  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(initialLives);
  const [running, setRunning] = useState(false);
  const [level, setLevel] = useState(1);
  const [spawnInterval, setSpawnInterval] = useState(spawnIntervalBase);
  const spawnTimerRef = useRef(null);
  const [message, setMessage] = useState('Pulsa ▶ para comenzar');
  const [vaccineCharges, setVaccineCharges] = useState(1);

  function resetGame() {
    let repeated = [...baseElements];
    for(let i=0;i<5;i++) {
      const pick = baseElements[Math.floor(Math.random()*baseElements.length)];
      repeated.push({...pick});
    }
    setElements(repeated.map((el, idx) => ({...el, id: idx, status:'healthy'})));
    setScore(0); setLives(initialLives); setLevel(1);
    setSpawnInterval(spawnIntervalBase); setVaccineCharges(1);
    setMessage('Pulsa ▶ para comenzar'); setRunning(false); clearSpawn();
  }

  function spawnVirus() {
    setElements(prev => {
      const healthy = prev.filter(e=>e.status==='healthy');
      if(healthy.length===0) return prev;
      const pick = healthy[Math.floor(Math.random()*healthy.length)];
      return prev.map(e=>e.id===pick.id ? {...e, status:'infected', infectedAt:Date.now()} : e);
    });
  }

  function clearSpawn() { if(spawnTimerRef.current){ clearInterval(spawnTimerRef.current); spawnTimerRef.current=null; } }

  function toggleRunning() {
    if(running){ setRunning(false); setMessage('Pausado'); clearSpawn(); }
    else{ setRunning(true); setMessage('Protege la tabla: haz click en infectados'); spawnTimerRef.current = setInterval(spawnVirus, spawnInterval); }
  }

  useEffect(()=>{
    const newInterval = Math.max(400, Math.round(spawnIntervalBase-(level-1)*120));
    setSpawnInterval(newInterval);
    if(running){ clearSpawn(); spawnTimerRef.current=setInterval(spawnVirus,newInterval); }
  }, [level]);

  useEffect(()=>{
    const tick = setInterval(()=>{
      setElements(prev=>{
        let mutated=false;
        const now = Date.now();
        const newArr = prev.map(e=>{ if(e.status==='infected' && now-(e.infectedAt||now)>Math.max(1200,3500-level*200)){ mutated=true; return {...e,status:'damaged',infectedAt:null}; } return e; });
        if(mutated) setLives(l=>l-1);
        return newArr;
      })
    },600);
    return ()=>clearInterval(tick);
  }, [level]);

  useEffect(()=>{ if(lives<=0){ setMessage('Game Over — reinicia para jugar'); setRunning(false); clearSpawn(); } }, [lives]);

  function handleElementClick(id) {
    if(lives<=0) return;
    setElements(prev=>prev.map(e=>{
      if(e.id===id){
        if(e.status==='infected'){ setScore(s=>s+1); setLevel(lv=>{ const newScore=score+1; const newLevel=1+Math.floor(newScore/levelUpEvery); if(newLevel>lv) setVaccineCharges(c=>c+1); return newLevel; }); return {...e,status:'vaccinated',infectedAt:null}; }
        else if(e.status==='healthy'){ setScore(s=>Math.max(0,s-0.1)); return e; }
        else if(e.status==='damaged'){ setScore(s=>Math.max(0,s-0.5)); return {...e,status:'vaccinated',infectedAt:null}; }
      }
      return e;
    }));
  }

  function useGlobalVaccine(){ if(vaccineCharges<=0) return; setVaccineCharges(c=>c-1); setElements(prev=>prev.map(e=>(e.status==='infected'||e.status==='damaged'?{...e,status:'vaccinated',infectedAt:null}:e))); setScore(s=>s+2); setMessage('Vacuna global aplicada'); }

  useEffect(()=>{ const t=setInterval(()=>{ setElements(prev=>prev.map(e=>e.status==='vaccinated'?{...e,status:'healthy'}:e)); },5000); return ()=>clearInterval(t); },[]);

  function statusClass(status){ if(status==='healthy')return''; if(status==='infected')return'infected'; if(status==='damaged')return'damaged'; if(status==='vaccinated')return'vaccinated'; return''; }

  return (
    <div className="container">
      <div className="header">
        <h1>Virus — Tabla Periódica (36 cartas)</h1>
        <div style={display:'flex',gap:8}>
          <button onClick={toggleRunning} className="badge">{running?'Pausar':'▶ Iniciar'}</button>
          <button onClick={resetGame} className="badge">Reiniciar</button>
          <button onClick={useGlobalVaccine} className="badge" disabled={vaccineCharges<=0}>Vacuna x{vaccineCharges}</button>
        </div>
      </div>

      <div style={display:'flex',gap:12,marginBottom:12}>
        <div className="badge">Puntuación: {Math.round(score)}</div>
        <div className="badge">Nivel: {level}</div>
        <div className="badge">Vidas: {lives}</div>
        <div className="badge">{message}</div>
      </div>

      <div className="grid">
        {elements.map(el=>(
          <button key={el.id} onClick={()=>handleElementClick(el.id)} className={"tile "+statusClass(el.status)} title={`${el.name} (${el.s}) — estado: ${el.status}`}>
            <div style={display:'flex',justifyContent:'space-between'}>
              <div style={fontSize:12,fontWeight:600}>{el.z}</div>
              <div style={fontSize:12}>{el.status==='infected'?'🦠':el.status==='vaccinated'?'💉':''}</div>
            </div>
            <div style={alignSelf:'center',fontSize:20,fontWeight:700}>{el.s}</div>
            <div style={fontSize:12,opacity:0.8}>{el.name}</div>
          </button>
        ))}
      </div>
    </div>
  )
}
